﻿//2 уровень 1 задача
using System;
using Лаба_9._2.Serializers2;
using ProtoBuf;
[ProtoContract]
[ProtoInclude(1, typeof(students))]
[ProtoInclude(2, typeof(Worker))]
public class Person
{
    public Person() { }
    protected string famile;
    [ProtoMember(3)]
    public string Famile { get { return famile; } set { famile = value; } }
    public virtual void Print(string text = "Некорректная фамилия")
    {
        if (famile != null)
        {
            text = famile;
        }
        Console.WriteLine(text);
    }
}
[ProtoContract]
public class students : Person
{
    public students() : base() { }
    protected int studticket;
    [ProtoMember(4)]
    public int Studticket { get { return studticket; } set { studticket = value; } }
    private double rez;

    [ProtoMember(5)]
    public double Rez { get { return rez; } set { rez = value; } }

    public students(string famile, int studticket, double x, double y, double z, double w)
    {
        this.famile = famile;
        rez = (x + y + z + w) / 4;
        this.studticket = studticket;
    }
    public override void Print(string text = "Некорректная фамилия")
    {
        if (famile != null)
        {
            text = famile + "   " + "Средний балл" + " " + rez + "  " + "Студенский билет " + studticket;
        }
        if (rez >= 4)
        {
            Console.WriteLine(text);
        }
    }
}
[ProtoContract]
public class Worker: Person
{
    public Worker() : base() { }
    protected string post;
    [ProtoMember(6)]
    public string Post { get { return post; } set { post = value;} }
    protected int seniority;
    [ProtoMember(7)]
    public int Seniority { get { return seniority; } set { seniority = value; } }
    
    protected int ID;
    [ProtoMember(8)]
    public int id { get { return ID; } set { ID = value; } }
    public Worker(int ID, string famile, string post, int seniority)
    {
        this.famile = famile;
        this.ID = ID;
        this.post = post;
        this.seniority = seniority;
    }
    public override void Print(string text = "Некорректная фамилия")
    {
        if(famile!= null)
        {
            text = ID + "   " + famile + "   " + "Должность:" + " " + post + " " + "Стаж:" + " " + seniority;
        }
        Console.WriteLine(text);
        
    }
}

class Program
{
    static void Main(string[] args)
    {
        students[] os = new students[4];
        os[0] = new students("Романов", 7182, 3.0, 5.0, 5.0, 4.0);
        os[1] = new students("Кузнецов", 1436, 4.0, 5.0, 4.0, 5.0);
        os[2] = new students("Печугин", 0104, 3.0, 3.0, 4.0, 3.0);
        os[3] = new students("Лавров", 0372, 5.0, 5.0, 5.0, 5.0);
        Sort(os);
        foreach (students students in os)
        {
            students.Print();
        }


        ISer2[] serializers1 = new ISer2[3]
        {
            new JsonSer2(),
            new XMLSer2(),
            new BinSer2()
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Person1";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
        string[] files1 = new string[3]
        {
            "Person1.json",
            "Person1.xml",
            "Person1.bin"
        };
        for (int i = 0; i < serializers1.Length; i++)
        {
            serializers1[i].Write(os, Path.Combine(path, files1[i]));
        }
        for (int i = 0; i < serializers1.Length; i++)
        {
            os = serializers1[i].Read<students[]>(Path.Combine(path, files1[i]));
            for (int j = 0; j < os.Length; j++)
            {
                os[j].Print();
            }
        }
        Worker[] workers = new Worker[3];
        workers[0] = new Worker(1,"Романчук", "Директор", 5);
        workers[1] = new Worker(2, "Белова", "Бухгалтер", 3);
        workers[2] = new Worker(3, "Русаков", "Юрист", 9);
        foreach(Worker worker in workers)
        {
            worker.Print();
        }
        ISer2[] serializers2 = new ISer2[3]
        {
            new JsonSer2(),
            new XMLSer2(),
            new BinSer2()
        };
        string path2 = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder2 = "Person2";
        path2 = Path.Combine(path2, folder2);
        if (!Directory.Exists(path2))
        {
            Directory.CreateDirectory(path2);
        }
        string[] files2 = new string[3]
        {
            "Person2.json",
            "Person2.xml",
            "Person2.bin"
        };
        for (int i = 0; i < serializers2.Length; i++)
        {
            serializers2[i].Write(workers, Path.Combine(path2, files2[i]));
        }
        for(int i = 0; i < serializers2.Length; i++)
        {
            workers = serializers2[i].Read<Worker[]>(Path.Combine(path2, files2[i]));
            for(int j = 0; j < workers.Length; j++)
            {
                workers[j].Print();
            }
        }
    }

    static void Sort(students[] a)
    {
        for (int i = 0; i < a.Length - 1; i++)
        {
            double amax = a[i].Rez;
            int imax = i;
            for (int j = i; j < a.Length; j++)
            {
                if (a[i].Rez > amax)
                {
                    amax = a[j].Rez;
                    imax = j;
                }
            }
            students temp;
            temp = a[imax];
            a[imax] = a[i];
            a[i] = temp;
        }
    }
}