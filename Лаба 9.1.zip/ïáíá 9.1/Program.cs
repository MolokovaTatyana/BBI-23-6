﻿using System;
using ConsoleApp16.Serializers1;
using ProtoBuf;
[ProtoContract]
public class Sportsmen
{
    private string famile;
    private double rez1, rez2, rez;
    private bool dis = false;
    [ProtoMember(1)]
    public string Famile { get { return famile; } set { famile = value; } }


    public void Diss()
    {
        dis = true;
    }
    [ProtoMember(2)]
    public Double Rez { get { return rez; } set { rez = value; } }
    private double max(double x, double y)
    {
        if (x > y)
        {
            return x;
        }
        else
        {
            return y;
        }
    }
    public Sportsmen() { }
    public Sportsmen(string famile1, double rezz1, double rezz2)
    {
        famile = famile1;
        rez1 = rezz1;
        rez2 = rezz2;
        rez = max(rez1, rez2);
    }
    public void Print()
    {
        if (dis == false)
        {
            Console.WriteLine("Фамилия {0}\t  Результат  {1:f2}", famile, rez);
        }
    }
}
class Program
{
    static void Main(string[] args)
    {
        Sportsmen[] sp = new Sportsmen[3];
        sp[0] = new Sportsmen("Романов", 1.48, 1.52);
        sp[1] = new Sportsmen("Кузнецов", 1.6, 1.55);
        sp[2] = new Sportsmen("Лавров", 1.39, 1.35);
        for (int i = 0; i < sp.Length; i++)
        {
            sp[i].Print();
        }
        for (int i = 0; i < sp.Length - 1; i++)
        {
            double amax = sp[i].Rez;
            int imax = i;
            for (int j = i + 1; j < sp.Length; j++)
            {
                if (sp[j].Rez > amax)
                {
                    amax = sp[j].Rez;
                    imax = j;
                }
            }
            Sportsmen temp;
            temp = sp[imax];
            sp[imax] = sp[i];
            sp[i] = temp;
        }
        Console.WriteLine();
        sp[0].Diss();
        for (int i = 0; i < sp.Length; i++)
        {
            sp[i].Print();

        }


        ISer1[] serializers = new ISer1[3]
        {
            new JsonSer1(),
            new XMLSer1(),
            new BinSer1()
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Sportsmen";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
        string[] files = new string[3]
        {
            "sportsmen.json",
            "sportsmen.xml",
            "sportsmen.bin"
        };
        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(sp, Path.Combine(path, files[i]));
        }
        for (int i = 0; i < serializers.Length; i++)
        {
            sp = serializers[i].Read<Sportsmen[]>(Path.Combine(path, files[i]));
            for (int j = 0; j < sp.Length; j++)
            {
                sp[j].Print();
            }
        }


    }
}