﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Лаба_9._3.Serializers3
{
    internal interface ISer3
    {
        public void Write<T>(T obj, string path);
        public T Read<T>(string path);
    }
}
