﻿//3 уровень 1 задача
using System;
using Лаба_9._3.Serializers3;
using ProtoBuf;
[ProtoContract]
[Serializable]
[ProtoInclude (1, typeof(BBI1_Group))]
[ProtoInclude(2, typeof(BBI2_Group))]
[ProtoInclude(3, typeof(BBI3_Group))]
public class Group
{
    public Group() { }
    protected double srball;
    public double sr(double[] a)
    {
        double sum = 0;
        for (int i = 0; i < a.Length; i++)
        {
            sum += a[i];
        }
        sum = sum / a.Length;
        return sum;
    }
    [ProtoMember(4)]
    public double Srball { get { return srball; } set { srball = value; } }
    public Group(double[] b1, double[] b2, double[] b3)
    {
        srball = (sr(b1) + sr(b2) + sr(b3)) / 3;
    }
    public void Print()
    {
        Console.WriteLine("cредний балл - " + Math.Round(srball, 2));
    }
}
[ProtoContract]
[Serializable]
public class BBI1_Group : Group
{
    public BBI1_Group(): base() { }
    public BBI1_Group(double[] informatic, double[] maths, double[] b1, double[] b2, double[] b3) : base(b1, b2, b3)
    {
        srball = (sr(b1) + sr(b2) + sr(b3) + sr(informatic) + sr(maths)) / 5;
    }
}
[ProtoContract]
[Serializable]
public class BBI2_Group : Group
{
    public BBI2_Group(): base() { }
    public BBI2_Group(double[] literature, double[] english, double[] b1, double[] b2, double[] b3) : base(b1, b2, b3)
    {
        srball = (sr(b1) + sr(b2) + sr(b3) + sr(literature) + sr(literature)) / 5;
    }
}
[ProtoContract]
[Serializable]
public class BBI3_Group : Group
{
    public BBI3_Group(): base() { }
    public BBI3_Group(double[] physics, double[] biology, double[] b1, double[] b2, double[] b3) : base(b1, b2, b3)
    {
        srball = (sr(b1) + sr(b2) + sr(b3) + sr(physics) + sr(biology)) / 5;
    }
}
class Program
{

    static void Main(string[] args)
    {
        double[] informatic = new double[3] { 4.0, 3.0, 5.0 };
        double[] maths = new double[3] { 4.0, 4.0, 3.0 };
        double[] b1 = new double[3] { 5.0, 4.0, 4.0 };
        double[] b2 = new double[3] { 5.0, 5.0, 3.0 };
        double[] b3 = new double[3] { 3.0, 3.0, 3.0 };
        BBI1_Group G23_6 = new BBI1_Group(informatic, maths, b1, b2, b3);

        double[] literature = new double[3] { 5.0, 5.0, 5.0 };
        double[] english = new double[3] { 4.0, 5.0, 5.0 };
        double[] p1 = new double[3] { 3.0, 4.0, 5.0 };
        double[] p2 = new double[3] { 4.0, 5.0, 3.0 };
        double[] p3 = new double[3] { 3.0, 5.0, 5.0 };
        BBI1_Group G23_5 = new BBI1_Group(literature, english, p1, p2, p3);

        double[] physics = new double[3] { 4.0, 5.0, 5.0 };
        double[] biology = new double[3] { 3.0, 3.0, 4.0 };
        double[] m1 = new double[3] { 5.0, 4.0, 5.0 };
        double[] m2 = new double[3] { 4.0, 3.0, 4.0 };
        double[] m3 = new double[3] { 3.0, 5.0, 4.0 };
        BBI1_Group G23_4 = new BBI1_Group(physics, biology, m1, m2, m3);

        BBI1_Group[] groups = new BBI1_Group[3] {G23_6, G23_5, G23_4 };
        for (int i = 0; i < 3; i++)
        {
            for (int j = 0; j < 2; j++)
            {
                if (groups[j].Srball < groups[j + 1].Srball)
                {
                    var m = groups[j];
                    groups[j] = groups[j + 1];
                    groups[j + 1] = m;

                }
            }
        }
        for (int i = 0; i < 3; i++)
        {
            Console.Write("Группа " + (i + 1) + "   ");
            groups[i].Print();
        }
        ISer3[] serializers = new ISer3[3]
        {
            new JsonSer3(),
            new XMLSer3(),
            new BinSer3()
        };
        string path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
        string folder = "Groups";
        path = Path.Combine(path, folder);
        if (!Directory.Exists(path))
        {
            Directory.CreateDirectory(path);
        }
        string[] files = new string[3]
        {
            "Groups.json",
            "Groups.xml",
            "Groups.bin"
        };
        for (int i = 0; i < serializers.Length; i++)
        {
            serializers[i].Write(groups, Path.Combine(path, files[i]));
        }
        for (int i = 0; i < serializers.Length; i++)
        {
            Console.WriteLine(i + 1);
            groups = serializers[i].Read<BBI1_Group[]>(Path.Combine(path, files[i]));
            for (int j = 0; j < groups.Length; j++)
            {
                groups[j].Print();
            }
        }
    }
}

